
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';

import Home from './pages/Home';
import Challenges from './pages/Challenges';
import About from './pages/About';
import Affiliate from './pages/Affiliate';
import Portal from './pages/Portal';
import Contact from './pages/Contact';
import Terms from './pages/Terms';
import ThankYou from './pages/ThankYou';

function App() {
  return (
    <Router>
      <Navbar />
      <main className="bg-black text-white min-h-screen">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/challenges" element={<Challenges />} />
          <Route path="/about" element={<About />} />
          <Route path="/affiliate" element={<Affiliate />} />
          <Route path="/portal" element={<Portal />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/thank-you" element={<ThankYou />} />
        </Routes>
      </main>
      <Footer />
    </Router>
  );
}

export default App;
