
import React from 'react';

export default function ChallengeCard({ tier, price, target, drawdown, link }) {
  return (
    <div className="bg-gray-900 border border-gray-700 p-6 rounded-lg shadow-lg hover:scale-105 transition">
      <h3 className="text-xl font-bold text-aqua-500">{tier} Challenge</h3>
      <p className="text-white my-2">Entry Fee: <strong>{price}</strong></p>
      <p>Target: {target} | Max Drawdown: {drawdown}</p>
      <a href={link} className="mt-4 inline-block bg-aqua-500 text-black px-4 py-2 rounded font-semibold shadow hover:bg-aqua-400">Get Funded</a>
    </div>
  );
}
