
import React from 'react';
import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav className="bg-gray-900 text-white px-6 py-4 flex justify-between items-center">
      <Link to="/" className="text-2xl font-bold text-aqua-500">Hybrid Funding</Link>
      <div className="space-x-4">
        <Link to="/" className="hover:text-aqua-500">Home</Link>
        <Link to="/challenges" className="hover:text-aqua-500">Challenges</Link>
        <Link to="/about" className="hover:text-aqua-500">About</Link>
        <Link to="/affiliate" className="hover:text-aqua-500">Affiliates</Link>
        <Link to="/portal" className="hover:text-aqua-500">Portal</Link>
        <Link to="/contact" className="hover:text-aqua-500">Contact</Link>
      </div>
    </nav>
  );
}
