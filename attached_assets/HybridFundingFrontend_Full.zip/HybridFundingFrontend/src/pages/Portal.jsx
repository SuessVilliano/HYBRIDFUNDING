
import React from 'react';

export default function Portal() {
  return (
    <section className="p-8 text-white text-center">
      <h2 className="text-3xl font-bold mb-2">Access Your Funded Trader Portal</h2>
      <p className="mb-4">After purchasing a challenge, your login credentials will be delivered by email. This gives you access to your private trader dashboard and challenge metrics.</p>
      <a href="https://client.hybridfunding.club/login" target="_blank" rel="noopener" className="bg-aqua-500 text-black px-6 py-3 rounded-lg font-bold shadow-md hover:scale-105">Login to Your Portal</a>
      <p className="mt-4 text-sm">If you haven’t received credentials within 30 minutes, please check your spam folder or contact <strong>support@hybridfunding.club</strong>.</p>
    </section>
  );
}
