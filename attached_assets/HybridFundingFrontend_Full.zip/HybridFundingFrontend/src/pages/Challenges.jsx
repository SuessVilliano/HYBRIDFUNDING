
import React from 'react';
import ChallengeCard from '../components/ChallengeCard';

const challenges = [
  { tier: '5K', price: '$49', target: '8%', drawdown: '5%', link: '/checkout/5k' },
  { tier: '10K', price: '$89', target: '8%', drawdown: '5%', link: '/checkout/10k' },
  { tier: '25K', price: '$139', target: '10%', drawdown: '8%', link: '/checkout/25k' },
  { tier: '50K', price: '$199', target: '10%', drawdown: '8%', link: '/checkout/50k' },
  { tier: '100K', price: '$299', target: '10%', drawdown: '10%', link: '/checkout/100k' },
  { tier: '200K', price: '$499', target: '10%', drawdown: '10%', link: '/checkout/200k' }
];

export default function Challenges() {
  return (
    <section className="p-8 text-white">
      <h2 className="text-3xl font-bold mb-6">Choose Your Challenge</h2>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {challenges.map((ch, idx) => (
          <ChallengeCard key={idx} {...ch} />
        ))}
      </div>
    </section>
  );
}
