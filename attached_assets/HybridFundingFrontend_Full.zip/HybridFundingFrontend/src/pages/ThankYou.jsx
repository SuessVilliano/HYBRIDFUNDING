
import React from 'react';

export default function ThankYou() {
  return (
    <section className="p-8 text-white text-center">
      <h2 className="text-3xl font-bold mb-4">Thank You for Your Purchase!</h2>
      <p className="mb-4">Your login details will be emailed shortly. If you don’t see the email, please check your spam folder or contact support.</p>
      <a href="/portal" className="inline-block bg-aqua-500 text-black px-6 py-3 rounded-lg font-bold shadow-md hover:scale-105">Go to Portal</a>
    </section>
  );
}
