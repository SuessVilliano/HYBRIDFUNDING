
import React from 'react';
import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <section className="bg-gradient-to-br from-purple-900 via-indigo-900 to-blue-900 text-white min-h-screen p-10">
      <h1 className="text-4xl md:text-6xl font-bold mb-4">Empowering Traders. Funding Potential.</h1>
      <p className="mb-6 max-w-xl">Hybrid Funding is the modern prop firm built by traders, for traders — with a mission to fund top talent and democratize access to capital through real-world trading evaluations.</p>
      <Link to="/challenges" className="bg-aqua-500 text-black font-bold px-6 py-3 rounded-lg shadow-lg hover:scale-105 transition">Choose Your Challenge</Link>
    </section>
  );
}
