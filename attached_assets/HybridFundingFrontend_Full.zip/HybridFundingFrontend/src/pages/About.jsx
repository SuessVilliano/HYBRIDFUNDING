
import React from 'react';

export default function About() {
  return (
    <section className="p-8 text-white max-w-4xl mx-auto">
      <h2 className="text-4xl font-bold mb-4">About Hybrid Funding</h2>
      <p className="mb-4">Hybrid Funding is a Delaware-based proprietary trading firm created to unlock access to capital for disciplined traders worldwide. With an emphasis on HUBZone development and financial literacy, we bridge the gap between ambition and opportunity.</p>
      <p>Our founding team includes graduates of Caravel Academy and veterans of both traditional and algorithmic trading spaces. We believe funding shouldn’t be limited to hedge funds and elite traders — it belongs in the hands of the people. That’s why our ecosystem, powered by Hybrid Holdings, enables real pathways to funded trading and generational wealth.</p>
    </section>
  );
}
