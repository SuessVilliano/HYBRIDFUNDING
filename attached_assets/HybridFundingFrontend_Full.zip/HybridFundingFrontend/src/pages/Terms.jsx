
import React from 'react';

export default function Terms() {
  return (
    <section className="p-8 text-white max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold mb-4">Terms & Policies</h2>
      <p className="mb-2">By participating in our trading evaluations, you agree to adhere to all drawdown and profit rules. Refunds are not issued after the challenge begins unless otherwise specified.</p>
      <p className="mb-2">All KYC documentation is securely stored and never sold. See our Privacy Policy for full details.</p>
      <p>If you have questions, contact support@hybridfunding.club.</p>
    </section>
  );
}
