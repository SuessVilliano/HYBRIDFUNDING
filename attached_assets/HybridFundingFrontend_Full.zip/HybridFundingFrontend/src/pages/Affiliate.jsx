
import React from 'react';

export default function Affiliate() {
  return (
    <section className="p-8 text-white max-w-4xl mx-auto">
      <h2 className="text-3xl font-bold mb-4">Affiliate Program</h2>
      <p>Share Hybrid Funding with your network and earn commission for every trader who joins through your link. We pay up to 20% per signup — no cap on earnings!</p>
      <ul className="list-disc list-inside mt-4">
        <li>Tiered commissions for high-performers</li>
        <li>Custom dashboard and link tracking</li>
        <li>Weekly payouts via Stripe or PayPal</li>
      </ul>
      <a href="https://forms.gle/affiliate-signup" target="_blank" rel="noopener" className="inline-block mt-6 bg-aqua-500 text-black px-6 py-3 rounded-lg font-bold shadow-md hover:scale-105">Apply to Join</a>
    </section>
  );
}
