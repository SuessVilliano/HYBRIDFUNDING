
module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}", "./public/index.html"],
  theme: {
    extend: {
      colors: {
        aqua: {
          500: "#00FFFF"
        },
        cyberpunk: {
          purple: "#8A2BE2"
        }
      }
    },
  },
  plugins: [],
}
